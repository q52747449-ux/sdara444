# Nova Market PRO

Advanced demo e-commerce project.

## Features
- Product listing
- Admin panel (add products)
- Cart system with quantity
- Search system
- LocalStorage database (no backend)

## How to use
1. Open index.html
2. Open admin.html to add products
3. Everything updates automatically

## Upgrade idea
Connect Firebase for real users and cloud database.
